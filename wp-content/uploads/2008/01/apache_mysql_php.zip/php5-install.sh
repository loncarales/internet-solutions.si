#!/bin/sh

#
# Compiles and installs php5
# 
# @author Ales Loncar <ales.loncar@internet-solutions.si>
# @copyright 	Copyright (c) 2008 Internet Solutions
# @license GNU Public License
# @link http://www.internet-solutions.si
# @version 1.0

echo 
echo php5-install.sh
echo - This script compiles and installs php5
echo - Run php5-pre-install.sh before running this script
echo
read -p  "(Press any key to continue)" temp;
echo

# Abort on any errors
set -e

#source directory (/usr/local/src)
SRCDIR=/usr/local/src

# And where should it be installed? (/usr/local)
INSTALLDIR=/usr/local

# imap
CCLIENT_DIR="imap-2007"
# php
PHP="php-5.2.5"

#
# PHP 5
#

echo
echo --- Building PHP 5 ---
echo
cd ${SRCDIR}/${PHP}
echo "    Configuring..."
./configure \
--with-apxs2=${INSTALLDIR}/apache2/bin/apxs \ 
--with-config-file-path=${INSTALLDIR}/apache2/conf \
--with-mysql=${INSTALLDIR}/mysql \
--with-mysqli=${INSTALLDIR}/mysql/bin/mysql_config \
--with-mysql-sock=/var/lib/mysql/mysql.sock \
--with-zlib --enable-pdo=shared --with-pdo-sqlite=shared --with-sqlite=shared \
--with-zlib-dir==${INSTALLDIR} \
--with-iconv \
--with-curl=${INSTALLDIR} \
--with-openssl=${INSTALLDIR} \
--enable-inline-optimization \
--disable-debug \
--enable-bcmath \
--enable-calendar \
--enable-ctype \ 
--enable-dbase \
--enable-discard-path \
--enable-exif \
--enable-force-cgi-redirect \
--enable-ftp \
--enable-gd-native-ttf \
--with-ttf \
--enable-magic-quotes \
--enable-shmop \
--enable-sigchild \
--enable-sysvsem \
--enable-sysvshm \
--enable-wddx \
--with-jpeg-dir=${INSTALLDIR} \
--with-png-dir=${INSTALLDIR} \
--with-freetype-dir=${INSTALLDIR} \
--with-xsl=${INSTALLDIR} \
--with-gd \
--with-imap-ssl \
--with-imap=${INSTALLDIR}/${CCLIENT_DIR} \
--with-mcrypt=${INSTALLDIR} \
--with-mhash=${INSTALLDIR} \
--enable-sockets \
--enable-mbstring=all \
--enable-mbregex \
--enable-zend-multibyte \
--enable-exif \
--with-libxml-dir=${INSTALLDIR} \
--enable-soap \
--enable-pcntl \
--with-mime-magic
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
