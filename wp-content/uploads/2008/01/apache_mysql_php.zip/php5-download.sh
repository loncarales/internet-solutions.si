#!/bin/sh

#
# Downloads and unpacks php5 with dependencies
# 
# @author Ales Loncar <ales.loncar@internet-solutions.si>
# @copyright 	Copyright (c) 2008 Internet Solutions
# @license GNU Public License
# @link http://www.internet-solutions.si
# @version 1.0

echo
echo php-download.sh
echo - This script downloads and unpacks all prerequisite packages
echo - Run this script before php2-install.sh
echo
read -p  "(Press any key to continue)" temp;
echo

# Abort on any errors
set -e

#source directory (/usr/local/src)
SRCDIR=/usr/local/src

# Set DISTDIR to somewhere persistent, if you plan to muck around with this
# script and run it several times!
DISTDIR=/usr/local/dist

# Update version information here.
# libXML
LIBXML2="libxml2-2.6.31"
# libxslt
LIBXSLT="libxslt-1.1.22"
# libmcrypt
LIBMCRYPT="libmcrypt-2.5.8"
# mhash
MHASH="mhash-0.9.9"
# libidn
LIBIDN="libidn-1.4"
# freetype
FREETYPE="freetype-2.3.5"
# curl
CURL="curl-7.16.4"
# jpeg-6b
JPEG6b="jpegsrc.v6b"
# png
LIBPNG="libpng-1.2.24"
# imap
CCLIENT="imap-2007"
CCLIENT_DIR="imap-2007"
# php
PHP="php-5.2.5"

cd ${DISTDIR}

# Get all the required packages
echo
echo --- Downloading all required packages ---
echo

# libXML2
wget -c ftp://xmlsoft.org/libxml2/${LIBXML2}.tar.gz
# LIBXSLT
wget -c ftp://xmlsoft.org/libxml2/${LIBXSLT}.tar.gz
# LIBMCRYPT
wget -c http://mesh.dl.sourceforge.net/sourceforge/mcrypt/${LIBMCRYPT}.tar.gz
# MHASH
wget -c http://mesh.dl.sourceforge.net/sourceforge/mhash/${MHASH}.tar.gz
# LIBIDN
wget -c ftp://alpha.gnu.org/pub/gnu/libidn/${LIBIDN}.tar.gz
# FREETYPE
wget -c http://surfnet.dl.sourceforge.net/sourceforge/freetype/${FREETYPE}.tar.gz
# CURL
wget -c http://curl.haxx.se/download/${CURL}.tar.gz
# JPEG6b
wget -c ftp://ftp.uu.net/graphics/jpeg/${JPEG6b}.tar.gz
# LIBPNG
wget -c http://switch.dl.sourceforge.net/sourceforge/libpng/${LIBPNG}.tar.gz
# IMAP
wget -c ftp://ftp.cac.washington.edu/imap/${CCLIENT}.tar.Z
# PHP
wget -c http://si2.php.net/get/${PHP}.tar.gz/from/this/mirror

echo
echo --- Unpacking downloaded archives. This process may take several minutes! ---
echo

cd ${SRCDIR}
# Unpack them all
# libXML2
echo Extracting ${LIBXML2}...
tar xzf ${DISTDIR}/${LIBXML2}.tar.gz > /dev/null
echo Done.
# LIBXSLT
echo Extracting ${LIBXSLT}...
tar xzf ${DISTDIR}/${LIBXSLT}.tar.gz > /dev/null
echo Done.
# LIBMCRYPT
echo Extracting ${LIBMCRYPT}...
tar xzf ${DISTDIR}/${LIBMCRYPT}.tar.gz > /dev/null
echo Done.
# MHASH
echo Extracting ${MHASH}...
tar xzf ${DISTDIR}/${MHASH}.tar.gz > /dev/null
echo Done.
# LIBIDN
echo Extracting ${LIBIDN}...
tar xzf ${DISTDIR}/${LIBIDN}.tar.gz > /dev/null
echo Done.
# FREETYPE
echo Extracting ${FREETYPE}...
tar xzf ${DISTDIR}/${FREETYPE}.tar.gz > /dev/null
echo Done.
# CURL
echo Extracting ${CURL}...
tar xzf ${DISTDIR}/${CURL}.tar.gz > /dev/null
echo Done.
# JPEG6b
echo Extracting ${JPEG6b}...
tar xzf ${DISTDIR}/${JPEG6b}.tar.gz > /dev/null
echo Done.
# LIBPNG
echo Extracting ${LIBPNG}...
tar xzf ${DISTDIR}/${LIBPNG}.tar.gz > /dev/null
echo Done.
# CCLIENT
echo Extracting ${CCLIENT}...
uncompress -cd ${DISTDIR}/${CCLIENT}.tar.Z |tar x
echo Done.
# PHP
echo Extracting ${PHP}...
tar xzf ${DISTDIR}/${PHP}.tar.gz > /dev/null
echo Done.

echo --------------------------------------------------
echo -- Done downloading and unpacking prerequisites --
echo --------------------------------------------------