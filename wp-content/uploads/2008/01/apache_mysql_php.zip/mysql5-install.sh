#!/bin/sh

#
# Downloads and unpacks mysql5
# 
# @author Ales Loncar <ales.loncar@internet-solutions.si>
# @copyright 	Copyright (c) 2008 Internet Solutions
# @license GNU Public License
# @link http://www.internet-solutions.si
# @version 1.0

echo
echo mysql5-install.sh
echo - This script compiles and installs mysql5
echo - Run mysql5-download.sh before running this script
echo
read -p  "(Press any key to continue)" temp;
echo

# Abort on any errors
set -e

#source directory (/usr/local/src)
SRCDIR=/usr/local/src

# And where should it be installed? (/usr/local)
INSTALLDIR=/usr/local

# Update version information here.
# MySQL 5
MYSQL="mysql-5.0.51"

echo export CHOST="i686-pc-linux-gnu"
echo export CFLAGS="-mcpu=i686 -march=i686 -O3 -pipe -fomit-frame-pointer"
echo export CXX=gcc

echo ------------------------------------------------------
echo -- Compiling and installing MySql 5 			  --
echo ------------------------------------------------------
echo
echo --- Building: mysql5
echo
cd ${SRCDIR}/${MYSQL}
echo "    Configuring..."
./configure --prefix=${INSTALLDIR}/mysql --localstatedir=${INSTALLDIR}/mysql/data --with-mysqld-user=mysql --with-innodb --disable-shared --with-openssl --with-extra-charsets=all --enable-assembler --with-unix-socket-path=/var/lib/mysql/mysql.sock --enable-thread-safe-client --enable-assembler --enable-local-infile
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"