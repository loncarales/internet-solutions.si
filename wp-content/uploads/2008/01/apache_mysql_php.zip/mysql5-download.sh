#!/bin/sh

#
# Downloads and unpacks mysql5
# 
# @author Ales Loncar <ales.loncar@internet-solutions.si>
# @copyright 	Copyright (c) 2008 Internet Solutions
# @license GNU Public License
# @link http://www.internet-solutions.si
# @version 1.0

echo 
echo mysql5-download.sh
echo - This script downloads and unpacks all prerequisite packages
echo - Run this script before apache2-install.sh
echo
read -p  "(Press any key to continue)" temp;
echo

# Abort on any errors
set -e

#source directory (/usr/local/src)
SRCDIR=/usr/local/src

# Set DISTDIR to somewhere persistent, if you plan to muck around with this
# script and run it several times!
DISTDIR=/usr/local/dist

# Update version information here.
# MySQL 5
MYSQL="mysql-5.0.51"

cd ${DISTDIR}

# Get all the required packages
echo
echo --- Downloading all required packages ---
echo

# MySQL
wget -c http://dev.mysql.com/get/Downloads/MySQL-5.0/${MYSQL}.tar.gz/from/http://mirrors.bevc.net/mysql/

echo
echo --- Unpacking downloaded archives. This process may take several minutes! ---
echo

cd ${SRCDIR}
# Unpack them all
# Zlib
echo Extracting ${MYSQL}...
tar xzf ${DISTDIR}/${MYSQL}.tar.gz > /dev/null
echo Done.

echo --------------------------------------------------
echo -- Done downloading and unpacking prerequisites --
echo --------------------------------------------------