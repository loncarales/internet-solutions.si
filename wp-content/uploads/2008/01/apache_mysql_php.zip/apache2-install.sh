#!/bin/sh

#
# Compiles and installs apache2 and prerequisites
# 
# @author Ales Loncar <ales.loncar@internet-solutions.si>
# @copyright 	Copyright (c) 2008 Internet Solutions
# @license GNU Public License
# @link http://www.internet-solutions.si
# @version 1.0

echo
echo apache2-install.sh
echo - This script compiles and installs apache2 and all prerequisites
echo - Run apache2-download.sh before running this script
echo
read -p  "(Press any key to continue)" temp;
echo

# Abort on any errors
set -e

#source directory (/usr/local/src)
SRCDIR=/usr/local/src

# And where should it be installed? (/usr/local)
INSTALLDIR=/usr/local

# Update version information here.
# Zlib
ZLIB="zlib-1.2.3"
# OpenSSL
OPENSSL="openssl-0.9.7m"
# libiconv
LIBICONV="libiconv-1.12"
# apache2
HTTPD="httpd-2.2.8"

echo ------------------------------------------------------
echo -- Compiling and installing PHP 5 and prerequisites --
echo ------------------------------------------------------

# Build packages in the required order to satisfy dependencies.

#
# Zlib
#
echo
echo --- Building: zlib
echo
cd ${SRCDIR}/${ZLIB}
echo "    Configuring..."
./configure --shared --prefix=${INSTALLDIR}
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"

echo
read -p  "(Press any key to continue)" temp;
echo

#
# OpenSSL
#

echo
echo --- Building OpenSSL
echo
cd ${SRCDIR}/${OPENSSL}
echo "    Configuring..."
./config --prefix=${INSTALLDIR}
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"

echo
read -p  "(Press any key to continue)" temp;
echo

#
# libiconv
#

echo
echo --- Building libiconv
echo
cd ${SRCDIR}/${LIBICONV}
echo "    Configuring..."
./configure --enable-extra-encodings --prefix=${INSTALLDIR}
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"

echo
read -p  "(Press any key to continue)" temp;
echo

#
# apache2
#
echo
echo --- Building apache2
echo
cd ${SRCDIR}/${HTTPD}
echo "    Configuring..."
./configure \
--prefix=${INSTALLDIR}/apache2 \
--enable-mods-shared=all \
--with-ssl=${INSTALLDIR} \
--enable-ssl \
--enable-headers \
--enable-so \
--enable-auth-digest \
--enable-rewrite \
--enable-setenvif \
--enable-mime \
--enable-deflate
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"


echo ---------------------------------------
echo ---------- INSTALL COMPLETE! ----------
echo ---------------------------------------