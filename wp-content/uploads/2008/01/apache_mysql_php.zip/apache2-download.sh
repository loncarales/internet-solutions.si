#!/bin/sh

#
# Downloads and unpacks apache2 with dependencies
# 
# @author Ales Loncar <ales.loncar@internet-solutions.si>
# @copyright 	Copyright (c) 2008 Internet Solutions
# @license GNU Public License
# @link http://www.internet-solutions.si
# @version 1.0

echo
echo apache2-download.sh
echo - This script downloads and unpacks all prerequisite packages
echo - Run this script before apache2-install.sh
echo
read -p  "(Press any key to continue)" temp;
echo

# Abort on any errors
set -e

#source directory (/usr/local/src)
SRCDIR=/usr/local/src

# Set DISTDIR to somewhere persistent, if you plan to muck around with this
# script and run it several times!
DISTDIR=/usr/local/dist

# Update version information here.
# Zlib
ZLIB="zlib-1.2.3"
# OpenSSL
OPENSSL="openssl-0.9.7m"
# libiconv
LIBICONV="libiconv-1.12"
# apache2
HTTPD="httpd-2.2.8"

cd ${DISTDIR}

# Get all the required packages
echo
echo --- Downloading all required packages ---
echo

# Zlib
wget -c http://www.zlib.net/${ZLIB}.tar.gz
# OpenSSL
wget -c http://www.openssl.org/source/${OPENSSL}.tar.gz
# libiconv
wget -c http://ftp.gnu.org/pub/gnu/libiconv/${LIBICONV}.tar.gz
# apache2
wget -c http://www.apache.si/httpd/${HTTPD}.tar.gz


echo
echo --- Unpacking downloaded archives. This process may take several minutes! ---
echo

cd ${SRCDIR}
# Unpack them all
# Zlib
echo Extracting ${ZLIB}...
tar xzf ${DISTDIR}/${ZLIB}.tar.gz > /dev/null
echo Done.
# OpenSSL
echo Extracting ${OPENSSL}...
tar xzf ${DISTDIR}/${OPENSSL}.tar.gz > /dev/null
echo Done.
# libiconv
echo Extracting ${LIBICONV}...
tar xzf ${DISTDIR}/${LIBICONV}.tar.gz > /dev/null
echo Done.
# apache2
echo Extracting ${HTTPD}...
tar xzf ${DISTDIR}/${HTTPD}.tar.gz > /dev/null
echo Done.

echo --------------------------------------------------
echo -- Done downloading and unpacking prerequisites --
echo --------------------------------------------------