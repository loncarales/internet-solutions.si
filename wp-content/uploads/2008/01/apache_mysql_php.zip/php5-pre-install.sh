#!/bin/sh

#
# Compiles and installs php5 prerequisites
# 
# @author Ales Loncar <ales.loncar@internet-solutions.si>
# @copyright 	Copyright (c) 2008 Internet Solutions
# @license GNU Public License
# @link http://www.internet-solutions.si
# @version 1.0

echo 
echo php5-pre-install.sh
echo - This script compiles and installs php5 prerequisites
echo - Run php5-download.sh before running this script
echo
read -p  "(Press any key to continue)" temp;
echo

# Abort on any errors
set -e

#source directory (/usr/local/src)
SRCDIR=/usr/local/src

# And where should it be installed? (/usr/local)
INSTALLDIR=/usr/local

# Update version information here.
# libXML
LIBXML2="libxml2-2.6.31"
# libxslt
LIBXSLT="libxslt-1.1.22"
# libmcrypt
LIBMCRYPT="libmcrypt-2.5.8"
# mhash
MHASH="mhash-0.9.9"
# libidn
LIBIDN="libidn-1.4"
# freetype
FREETYPE="freetype-2.3.5"
# curl
CURL="curl-7.16.4"
# jpeg-6b
JPEG6b="jpeg-6b"
# png
LIBPNG="libpng-1.2.24"
# imap
CCLIENT="imap-2007"
CCLIENT_DIR="imap-2007"
# php
PHP="php-5.2.5"

#
# libxml2
#

echo
echo --- Building libxml2
echo
cd ${SRCDIR}/${LIBXML2}
echo "    Configuring..."
./configure --with-iconv=${INSTALLDIR} --prefix=${INSTALLDIR}
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"

echo
read -p  "(Press any key to continue)" temp;
echo

#
# libxslt
#

echo
echo --- Building libxslt
echo
cd ${SRCDIR}/${LIBXSLT}
echo "    Configuring..."
./configure --prefix=${INSTALLDIR} \
	--with-libxml-prefix=${INSTALLDIR} \
	--with-libxml-include-prefix=${INSTALLDIR}/include \
	--with-libxml-libs-prefix=${INSTALLDIR}/lib
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"

echo
read -p  "(Press any key to continue)" temp;
echo

#
# libmcrypt
#

echo
echo --- Building: libmcrypt
echo
cd ${SRCDIR}/${LIBMCRYPT}
echo "    Configuring..."
./configure --disable-posix-threads --prefix=${INSTALLDIR}
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"

#libmcrypt lltdl issue!!
cd  ${SRCDIR}/${LIBMCRYPT}/libltdl
echo "    Configuring..."
./configure --prefix=${INSTALLDIR} --enable-ltdl-install
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"

echo
read -p  "(Press any key to continue)" temp;
echo

#
# mhash
#

echo
echo --- Building: mhash
echo
cd ${SRCDIR}/${MHASH}
echo "    Configuring..."
./configure --prefix=${INSTALLDIR}
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"

echo
read -p  "(Press any key to continue)" temp;
echo

#
# libidn
#

echo
echo --- Building: libidn
echo
cd ${SRCDIR}/${LIBIDN}
echo "    Configuring..."
./configure --with-iconv-prefix=${INSTALLDIR} --prefix=${INSTALLDIR}
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"

echo
read -p  "(Press any key to continue)" temp;
echo

#
# freetype
#

echo
echo --- Building: freetype
echo
cd ${SRCDIR}/${FREETYPE}
echo     Configuring...
./configure --prefix=${INSTALLDIR}
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
echo "    Done!"

echo
read -p  "(Press any key to continue)" temp;
echo

#
# cURL
#

echo
echo --- Building: cURL
echo
cd ${SRCDIR}/${CURL}
echo     Configuring...
./configure --with-ssl=${INSTALLDIR}/ssl --with-zlib=${INSTALLDIR} \
	--with-libidn=${INSTALLDIR} --enable-ipv6 --enable-cookies \
	--enable-crypto-auth --prefix=${INSTALLDIR}
echo     Making...
nice -n 19 make
echo     Installing...
make install
echo     Done!

echo
read -p  "(Press any key to continue)" temp;
echo

#
# c-client
#

echo
echo --- Building: c-client
echo
cd ${SRCDIR}/${CCLIENT_DIR}
echo "    Making..."
make slx
echo "    Installing..."
mkdir ${INSTALLDIR}/${CCLIENT_DIR}
mkdir ${INSTALLDIR}/${CCLIENT_DIR}/include
mkdir ${INSTALLDIR}/${CCLIENT_DIR}/lib
cp c-client/c-client.a ${INSTALLDIR}/lib/libc-client.a
cp c-client/*.h ${INSTALLDIR}/${CCLIENT_DIR}/include
cp c-client/*.c ${INSTALLDIR}/${CCLIENT_DIR}/lib
echo "    Done!"

echo
read -p  "(Press any key to continue)" temp;
echo

#
# JPEG-6b
#

echo
echo --- Building JPEG-6b ---
echo

cd ${SRCDIR}/${JPEG6b}
echo "    Configuring..."
./configure --prefix=${INSTALLDIR}
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install
make install-lib

echo
read -p  "(Press any key to continue)" temp;
echo

#
# LIBPNG
#

echo
echo --- Building LIBPNG ---
echo

cd ${SRCDIR}/${LIBPNG}
echo "    Configuring..."
cp scripts/makefile.linux makefile
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install

echo
read -p  "(Press any key to continue)" temp;
echo

#
# PHP 5
#

echo
echo --- Building PHP 5 ---
echo
cd ${SRCDIR}/${PHP}
echo "    Configuring..."
./configure \
--with-apxs2=${INSTALLDIR}/apache2/bin/apxs \ 
--with-config-file-path=${INSTALLDIR}/apache2/conf \
--with-mysql=${INSTALLDIR}/mysql \
--with-mysqli=${INSTALLDIR}/mysql/bin/mysql_config \
--with-mysql-sock=/var/lib/mysql/mysql.sock \
--with-zlib --enable-pdo=shared --with-pdo-sqlite=shared --with-sqlite=shared \
--with-zlib-dir==${INSTALLDIR} \
--with-iconv \
--with-curl=${INSTALLDIR} \
--with-openssl=${INSTALLDIR}/ssl \
--enable-inline-optimization \
--disable-debug \
--enable-bcmath \
--enable-calendar \
--enable-ctype \ 
--enable-dbase \
--enable-discard-path \
--enable-exif \
--enable-filepro \
--enable-force-cgi-redirect \
--enable-ftp \
--enable-gd-imgstrttf \
--enable-gd-native-ttf \
--with-ttf \
--enable-magic-quotes \
--enable-memory-limit \
--enable-shmop \
--enable-sigchild \
--enable-sysvsem \
--enable-sysvshm \
--enable-track-vars \
--enable-trans-sid \
--enable-wddx \
--enable-yp \
--with-ftp \
--with-jpeg-dir=${INSTALLDIR} \
--with-png-dir=${INSTALLDIR} \
--with-freetype-dir=${INSTALLDIR} \
--without-xpm \
--enable-xslt=${INSTALLDIR} \
--with-xsl=${INSTALLDIR} \
--with-gd \
--with-imap-dir=${INSTALLDIR}/${CCLIENT_DIR} \
--with-imap-ssl \
--with-imap \
--with-mcrypt=${INSTALLDIR} \
--with-mhash=${INSTALLDIR} \
--enable-sockets \
--enable-mbstring=all \
--enable-mbregex \
--enable-zend-multibyte \
--enable-exif \
--with-libxml-dir=${INSTALLDIR} \
--enable-soap \
--enable-pcntl \
--with-mime-magic \
--enable-dio
echo "    Making..."
nice -n 19 make
echo "    Installing..."
make install