<?php
/* Facebook Like Box Block
 *
 * Adds a Facebook social plugin Like Box
 *
 * @ (C) Copyright 2010 by (internet-solutions.si | celavi.org) Ales Loncar
 * @ Version 0.1
 *
 */
class BlockFbLikeBox extends Module
{
    private $_html = '';
    private $_lb_facebook_page_id = '';
    private $_lb_width = '';
    private $_lb_height = '';
    private $_lb_connections = '';
    private $_lb_stream = '';
    private $_lb_header = '';

    function __construct()
    {
        $this->name = 'blockfblikebox';
        $this->tab  = 'internet-solutions.si | celavi.org';
        $this->version = 0.1;

        parent::__construct();
        $this->_refreshProperties();

        $this->displayName = $this->l('Facebook Like Box Block');
        $this->description = $this->l('Adds a Facebook social plugin Like Box');
    }

    public function install()
    {
        if (!parent::install() OR
            !$this->registerHook('rightColumn') )
                return false;
        Configuration::updateValue('LB_FACEBOOK_PAGE_ID','147527681944441');
        Configuration::updateValue('LB_WIDTH','190');
        Configuration::updateValue('LB_HEIGHT','300');
        Configuration::updateValue('LB_CONNECTIONS','9');
        return true;
    }

    function hookRightColumn($params)
    {
        global $smarty;

        $smarty->assign('facebook_page_id', $this->_lb_facebook_page_id);
        $smarty->assign('facebook_width', $this->_lb_width);
        $smarty->assign('facebook_height', $this->_lb_height);
        $smarty->assign('facebook_connections', $this->_lb_connections);
        $smarty->assign('facebook_stream', ($this->_lb_stream) ? 'true' : 'false');
        $smarty->assign('facebook_header', ($this->_lb_header) ? 'true' : 'false');

        return $this->display(__FILE__, 'blockfblikebox.tpl');
    }

    function hookLeftColumn($params)
    {
        return $this->hookRightColumn($params);
    }

    public function getContent()
    {
        $this->_html = '<h2>'.$this->displayName.'</h2>';
        $this->_postProcess();
        $this->_displayForm();
        return $this->_html;
    }

    private function _postProcess()
    {
        if (Tools::isSubmit('submitChanges')) {
            if (!Configuration::updateValue('LB_FACEBOOK_PAGE_ID', Tools::getValue('lb_facebook_page_id'))
                || !Configuration::updateValue('LB_WIDTH', Tools::getValue('lb_width'))
                || !Configuration::updateValue('LB_HEIGHT', Tools::getValue('lb_height'))
                || !Configuration::updateValue('LB_CONNECTIONS', Tools::getValue('lb_connections'))
                || !Configuration::updateValue('LB_STREAM', Tools::getValue('lb_stream'))
                || !Configuration::updateValue('LB_HEADER', Tools::getValue('lb_header')) )
                $this->_html .= '<div class="alert error">'.$this->l('Cannot update settings').'</div>';
            else
                $this->_html .= '<div class="conf confirm"><img src="../img/admin/ok.gif" alt="'.$this->l('Confirmation').'" />'.$this->l('Settings updated').'</div>';
        }
        $this->_refreshProperties();
    }

    private function _refreshProperties()
    {
        $this->_lb_facebook_page_id = Configuration::get('LB_FACEBOOK_PAGE_ID');
        $this->_lb_width            = Configuration::get('LB_WIDTH');
        $this->_lb_height           = Configuration::get('LB_HEIGHT');
        $this->_lb_connections      = Configuration::get('LB_CONNECTIONS');
        $this->_lb_stream           = Configuration::get('LB_STREAM');
        $this->_lb_header           = Configuration::get('LB_HEADER');
    }

    private function _displayForm()
    {
        $this->_html .= '
            <form action="'.$_SERVER['REQUEST_URI'].'" method="post">
                <fieldset class="width3" style="width:850px">
                    <legend><img src="'.$this->_path.'logo.gif" />'.$this->l('Facebook Like Box Settings').'</legend>
                    <label>'.$this->l('Facebook Page ID').'</label>
                    <div class="margin-form">
                        <input type="text" name="lb_facebook_page_id" value="'.Tools::getValue('lb_facebook_page_id', $this->_lb_facebook_page_id).'" />
                        <p class="clear">'.$this->l('The ID of the Facebook Page for this Like box.').'</p>
                    </div>
                    <label>'.$this->l('Width').'</label>
                    <div class="margin-form">
                        <input type="text" name="lb_width" value="'.Tools::getValue('lb_width', $this->_lb_width).'" />
                        <p class="clear">'.$this->l('The width of the plugin in pixels.').'</p>
                    </div>
                    <label>'.$this->l('Height').'</label>
                    <div class="margin-form">
                        <input type="text" name="lb_height" value="'.Tools::getValue('lb_height', $this->_lb_height).'" />
                        <p class="clear">'.$this->l('The height of the plugin in pixels.').'</p>
                    </div>
                    <label>'.$this->l('Connections').'</label>
                    <div class="margin-form">
                        <input type="text" name="lb_connections" value="'.Tools::getValue('lb_connections', $this->_lb_connections).'" />
                        <p class="clear">'.$this->l('Show a sample of this many users who have liked this Page.').'</p>
                    </div>
                    <label>'.$this->l('Show stream').'</label>
                    <div class="margin-form">
                        <input type="checkbox" name="lb_stream" value="1" '.( Tools::getValue('lb_stream', $this->_lb_stream) ? 'checked="checked"' : false ).' />
                        <p class="clear">'.$this->l('Show the profile stream for the public profile.').'</p>
                    </div>
                    <label>'.$this->l('Show header').'</label>
                    <div class="margin-form">
                        <input type="checkbox" name="lb_header" value="1" '.( Tools::getValue('lb_header', $this->_lb_header) ? 'checked="checked"' : false ).' />
                        <p class="clear">'.$this->l('Show the "Find us on Facebook" bar at top. Only shown when either stream or connections are present.').'</p>
                    </div>
                    <input type="submit" name="submitChanges" value="'.$this->l('Update').'" class="button" />
                </fieldset>
            </form>';
    }
}