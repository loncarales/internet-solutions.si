<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productrating}prestashop>productrating_5c64f6f998e4440ae6c1c1f8db892f1a'] = 'Oddajte svojo oceno';
$_MODULE['<{productrating}prestashop>productrating_dda9c06f33071c9b6fc237ee164109d8'] = 'Ocena';
$_MODULE['<{productrating}prestashop>productrating_54c280558263a67e0a84ba34f625c464'] = 'zabeleženih';
$_MODULE['<{productrating}prestashop>productrating_dfa5be7e620204da91e72a33294e9798'] = 'glasov';
$_MODULE['<{productrating}prestashop>productrating_4ca5d171acaac2c5ca261c97b0d40383'] = 'glasov';
$_MODULE['<{productrating}prestashop>productrating_663fc7093256cda156e571631ddb295e'] = 'od';
$_MODULE['<{productrating}prestashop>productrating_437866409d3a4a2ebdb33623a5b2a062'] = 'Hvala za vaš glas!';
