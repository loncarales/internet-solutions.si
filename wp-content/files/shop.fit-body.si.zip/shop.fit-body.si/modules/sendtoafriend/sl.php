<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sendtoafriend}prestashop>product_page_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'Pošlji prijatelju';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_c5f09f37e1e182ec28fa64732d9b712c'] = 'Nazaj';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_c38f24359344dada5d54e7eef08de8bb'] = 'Morate vpisati vsa polja';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_47f11ea69ec3161cab7c3434290efc8a'] = 'E-poštni naslov vašega prijatelja ni pravilen.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_97d4e28297c641ed0dbe3f0172f17fa6'] = 'Ime vašega prijatelja ni pravilno.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_a8197ef4bf125d45afdf7f1df4eee378'] = '5 mestno število se ne ujema.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_98db77c121d8acdba66ec89626ae896c'] = 'Med procesom je prišlo do napake.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_22c4733a9ceb239bf825a0cecd1cfaec'] = 'Prijatelj';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_bc8f7bbaaf366a6e4e174fd80dfece40'] = 'E-pošta je bila uspešno poslana na';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_2107f6398c37b4b9ee1e1b5afb5d3b2a'] = 'Pošlji prijatelju';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_20589174124c25654cac3736e737d2a3'] = 'Pošljite to stran prijatelju ki ga spodnji izdelek mogoče zanima.';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_cc5fd9b9f1cad59fcff97a1f21f34304'] = 'Pošlji sporočilo';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_19d305aea0ccec77d23362111ebdb6b4'] = 'Prijateljevo ime:';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_7ae8a9a7a5d8fa40d4515fc52f16bb2e'] = 'Prijateljev E-poštni naslov:';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_bba316d81bd5373409b992250440f85d'] = 'Spam zaščita';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_9f386f33c3b1fcf55668514ec325036d'] = 'Vtipkajte 5 mestno število';
$_MODULE['<{sendtoafriend}prestashop>sendtoafriend_2541d938b0a58946090d7abdde0d3890'] = 'pošlji';
