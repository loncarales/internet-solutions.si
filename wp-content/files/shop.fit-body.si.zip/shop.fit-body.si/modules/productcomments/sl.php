<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productcomments}prestashop>productcomments_0be8406951cdfda82f00f79328cf4efc'] = 'Komentar';
$_MODULE['<{productcomments}prestashop>productcomments_ad4ec284804b5d44a3e6de6c851e2731'] = 'Komentar je bil uspešno dodan.';
$_MODULE['<{productcomments}prestashop>productcomments_e1549cfa9780c9c706f9ea8fdc25e441'] = 'Objavljen bo ob potrditvi moderatorja.';
$_MODULE['<{productcomments}prestashop>productcomments_6bf852d9850445291f5e9d4740ac7b50'] = 'Prosimo vpišite komentar.';
$_MODULE['<{productcomments}prestashop>productcomments_5da618e8e4b89c66fe86e32cdafde142'] = 'Od';
$_MODULE['<{productcomments}prestashop>productcomments_08621d00a3a801b9159a11b8bbd69f89'] = 'Nihče še ni komentiral tega izdelka.';
$_MODULE['<{productcomments}prestashop>productcomments_c3edcf2cedbd4ce230fd6d4ea8915718'] = 'Dodaj komentar';
$_MODULE['<{productcomments}prestashop>productcomments_94966d90747b97d1f0f206c98a8b1ac3'] = 'Pošlji';
$_MODULE['<{productcomments}prestashop>productcomments_720fae7db6e6055d2b47890240bb3598'] = 'Samo registrirani uporabniki lahko dodajajo komentarje.';
$_MODULE['<{productcomments}prestashop>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Komentarji';
