<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productsalsobuy}prestashop>productsalsobuy_8e7a4dcba227eb5c3af2a2ace90aa7b2'] = 'Priporočamo';