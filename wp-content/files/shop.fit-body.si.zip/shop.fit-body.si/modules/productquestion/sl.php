<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{productquestion}prestashop>product_page_73b7bad4b638c7fca9d1263f5f9555be'] = 'Imate vprašanje?';
$_MODULE['<{productquestion}prestashop>productquestion_c5f09f37e1e182ec28fa64732d9b712c'] = 'Nazaj';
$_MODULE['<{productquestion}prestashop>productquestion_87308cdf4840bf140c52d934fbbdf922'] = 'Kupec';
$_MODULE['<{productquestion}prestashop>productquestion_70cd01a5d4d3aea87fa6c20841376905'] = 'vam pošilja vprašanje o';
$_MODULE['<{productquestion}prestashop>productquestion_17e620a3d332d5a3fe3321b2c1f17fb3'] = 'Obiskovalec';
$_MODULE['<{productquestion}prestashop>productquestion_de3f41a178e529363a23afa8b46babe1'] = 'Email je bil uspešno poslan!';
$_MODULE['<{productquestion}prestashop>productquestion_cc4d068b9cd706c568d84f7f1500983d'] = 'Imate vprašanje?';
$_MODULE['<{productquestion}prestashop>productquestion_499f8e221c7d6e8a69377ed399b75cdd'] = 'Če imate kakršnokoli vprašanje glede spodnjega izdelka nas kontaktirajte.';
$_MODULE['<{productquestion}prestashop>productquestion_f8c3d08ef76e1b81e3bbc7ee10e2fd3e'] = 'Pošljite vprašanje';
$_MODULE['<{productquestion}prestashop>productquestion_221e705c06e231636fdbccfdd14f4d5c'] = 'Vaše Ime';
$_MODULE['<{productquestion}prestashop>productquestion_d554d9bf0cd8f79c215600eeb77825e8'] = 'Vaš E-poštni naslov';
$_MODULE['<{productquestion}prestashop>productquestion_cfe1b4b75fb8dc152b124f9305835a11'] = 'Vaše sporočilo';
$_MODULE['<{productquestion}prestashop>productquestion_2541d938b0a58946090d7abdde0d3890'] = 'pošlji';
