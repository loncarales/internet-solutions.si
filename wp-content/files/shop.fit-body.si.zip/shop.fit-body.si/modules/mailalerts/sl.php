<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{mailalerts}prestashop>mailalerts_4c9120f1a5947445c0e9620254ceb30b'] = 'Novo naročilo';