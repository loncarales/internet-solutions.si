<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{birthdaypresent}prestashop>birthdaypresent_19f823c6453c2b1ffd09cb715214813d'] = 'Obvezno polje';
