<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockinfos}prestashop>blockinfos_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Informacije';
