<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{newsletter}prestashop>newsletter_ffb7e666a70151215b4c55c6268d7d72'] = 'E-novice';
