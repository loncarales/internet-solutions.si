<?php

global $_ERRORS;
$_ERRORS = array();
$_ERRORS['dea850f4b2aebd535089e1042c789b7c'] = 'Minimalni znesek';
$_ERRORS['eaa0d1591e6369a298dcd6cb1a8eba8a'] = 'Napačen E-mail';
$_ERRORS['12f9d32c39e630c928e001370285712c'] = 'Vaše geslo lahko ponovno generirate samo vsakih';
$_ERRORS['f78d03ece6d4341c3a5579730548c495'] = 'Za dostop do seznama želja se morate prijaviti ';
$_ERRORS['c41c77e4dddc04b1e0752a6050ae5656'] = 'overovitev ni bila uspešna';
$_ERRORS['8f17be67facaaef2526e4217f4b9b206'] = 'E-poštni naslov je obvezen';
$_ERRORS['7b8bee3f47b152d5e6a2911212b0f0e5'] = 'napačen E-poštni naslov';
$_ERRORS['703c2b69e5d9f7072b7db5338214448b'] = 'napačno geslo';
$_ERRORS['0a5fa53f3f20f67f98bd6c3b16df059d'] = 'je zahtevano';
$_ERRORS['5f32472177a71e8349dd4f30812c30cd'] = 'je obvezen za nadaljevanje nakupa';
$_ERRORS['e40246ff29a4c2e6b2c0bac01c5e7050'] = 'sporočilo ne more biti prazno';
$_ERRORS['ff30d300e1e8810211e29bb092decdf1'] = 'minut';
$_ERRORS['5eac234aa1a2dfba8005259230b3881e'] = 'geslo je prazno';
$_ERRORS['962c91be4b1056412febf0c272760814'] = 'geslo je zahtevano';
$_ERRORS['b94e28fcb3594165369a78965f7a96a0'] = 'geslo je predolgo';
$_ERRORS['fb32fd9bb2f3b22d3373f31cda7b4494'] = 'izberite kontakt na spisku';
$_ERRORS['e7d83586eea16295040d29c5426819b1'] = 'izdelek ni več na voljo';
$_ERRORS['add686afd8dca274d732bba1a401d877'] = 's tem E-poštnim naslovom je že nekdo registriran';
$_ERRORS['eb855616b4349507ebca091d2ba0af72'] = 's tem E-poštnim naslovom ni registriran noben račun';
$_ERRORS['a59940f8a657132cb9ffbd2c0a9c8a30'] = 'na zalogi ni dovolj izdelkov za vašo akcijo';
$_ERRORS['c53fcdf32e52ec2caa981e0d8b42e08d'] = 'ime kupona ni veljavno';
$_ERRORS['3b4e1297bba7c9992c2e345714233662'] = 'tega kupona ne morete uporabiti';
$_ERRORS['5eee906d0c9b5987d49076aef041a01d'] = 'tega kupona ne morete več uporabiti';

?>