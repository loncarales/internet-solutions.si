<?php

global $_FIELDS;
$_FIELDS = array();
$_FIELDS['Address_8ad75c5a8821cc294f189181722acb56'] = 'priimek';
$_FIELDS['Address_342f5c77ed008542e78094607ce1f7f3'] = 'ime';
$_FIELDS['Address_81e70cb16ec45f5ab19bb6638e8e6c2d'] = 'naslov';
$_FIELDS['Address_f669f8e9f6599d0dfcd613bc6e2f347e'] = 'naslov (2)';
$_FIELDS['Address_e90ebd9556fa4031171f043013794b61'] = 'poštna številka';
$_FIELDS['Address_4ed5d2eaed1a1fadcc41ad1d58ed603e'] = 'mesto';
$_FIELDS['Address_f7a42fe7211f98ac7a60a285ac3a9e87'] = 'kontaktni telefon';
$_FIELDS['Address_2df2ca5cf808744c2977e4073f6b59c8'] = 'mobilni telefon';
$_FIELDS['Customer_8ad75c5a8821cc294f189181722acb56'] = 'priimek';
$_FIELDS['Customer_342f5c77ed008542e78094607ce1f7f3'] = 'ime';
$_FIELDS['Customer_0c83f57c786a0b4a39efab23731c7ebc'] = 'e-poštni naslov';
$_FIELDS['Customer_76a2173be6393254e72ffa4d6df1030a'] = 'geslo';

?>