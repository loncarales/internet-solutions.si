<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockvariouslinks}fit_body_2>blockvariouslinks_d1aa22a3126f04664e0fe3f598994014'] = 'Akcijska ponudba';
$_MODULE['<{blockvariouslinks}fit_body_2>blockvariouslinks_02d4482d332e1aef3437cd61c9bcc624'] = 'Kontaktirajte nas';