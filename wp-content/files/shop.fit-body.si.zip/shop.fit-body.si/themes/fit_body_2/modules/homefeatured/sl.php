<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}fit_body_2>homefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'Artikli v akciji';
$_MODULE['<{homefeatured}fit_body_2>homefeatured_d3da97e2d9aee5c8fbe03156ad051c99'] = 'Več';
$_MODULE['<{homefeatured}fit_body_2>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Več';
$_MODULE['<{homefeatured}fit_body_2>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'V košarico';