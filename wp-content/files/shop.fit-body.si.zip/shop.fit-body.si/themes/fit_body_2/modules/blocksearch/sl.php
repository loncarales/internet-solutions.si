<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksearch}fit_body_2>blocksearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Išči';
$_MODULE['<{blocksearch}fit_body_2>blocksearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Išči';