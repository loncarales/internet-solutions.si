<?php

global $_LANGMAIL;
$_LANGMAIL = array();
$_LANGMAIL['Welcome!'] = 'Dobrodošli v spletno trgovino Fit Body Shop';
$_LANGMAIL['Your password'] = 'Vaše novo geslo';
$_LANGMAIL['Order confirmation'] = 'Podrobnosti naročila';
?>